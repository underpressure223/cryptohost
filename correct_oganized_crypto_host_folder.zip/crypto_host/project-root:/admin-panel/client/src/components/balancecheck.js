import React, { useState } from 'react';
import apiService from '../services/api.service';

function BalanceCheck() {
  const [balance, setBalance] = useState(null);

  const handleBalanceCheck = async () => {
    try {
      const response = await apiService.makeRequest('GET', '/balance');
      setBalance(response.balance);
    } catch (error) {
      setBalance(`Error: ${error.message}`);
    }
  };

  return (
    <div>
      <h2>Check Balance</h2>
      <button onClick={handleBalanceCheck}>Check Balance</button>
      {balance && (
        <div>
          <h3>Balance:</h3>
          <p>{balance}</p>
        </div>
      )}
    </div>
  );
}

export default BalanceCheck;
