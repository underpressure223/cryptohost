import React from 'react';
import { Switch, Route, Link } from 'react-router-dom';
import Transactions from './Transactions';
import TransactionDetail from './TransactionDetail';
import Users from './Users';
import Handshake from './Handshake';
import BalanceCheck from './BalanceCheck';
import Transfer from './Transfer';

function Dashboard() {
  return (
    <div>
      <nav>
        <ul>
          <li><Link to="/dashboard/transactions">Transactions</Link></li>
          <li><Link to="/dashboard/users">Users</Link></li>
          <li><Link to="/dashboard/handshake">Handshake</Link></li>
          <li><Link to="/dashboard/balance">Check Balance</Link></li>
          <li><Link to="/dashboard/transfer">Transfer USDT</Link></li>
        </ul>
      </nav>

      <Switch>
        <Route exact path="/dashboard/transactions" component={Transactions} />
        <Route path="/dashboard/transactions/:id" component={TransactionDetail} />
        <Route path="/dashboard/users" component={Users} />
        <Route path="/dashboard/handshake" component={Handshake} />
        <Route path="/dashboard/balance" component={BalanceCheck} />
        <Route path="/dashboard/transfer" component={Transfer} />
      </Switch>
    </div>
  );
}

export default Dashboard;
