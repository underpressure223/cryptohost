import React, { useState } from 'react';
import apiService from '../services/api.service';

function Handshake() {
  const [serverId, setServerId] = useState('');
  const [result, setResult] = useState(null);

  const handleHandshake = async (e) => {
    e.preventDefault();
    try {
      const response = await apiService.makeRequest('POST', '/handshake', { serverId });
      setResult(response);
    } catch (error) {
      setResult({ error: error.message });
    }
  };

  return (
    <div>
      <h2>Perform Handshake</h2>
      <form onSubmit={handleHandshake}>
        <input
          type="text"
          value={serverId}
          onChange={(e) => setServerId(e.target.value)}
          placeholder="Enter Server ID"
          required
        />
        <button type="submit">Perform Handshake</button>
      </form>
      {result && (
        <div>
          <h3>Result:</h3>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default Handshake;
