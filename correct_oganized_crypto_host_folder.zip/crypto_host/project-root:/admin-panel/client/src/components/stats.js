import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Stats() {
  const [stats, setStats] = useState({});

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get('/api/stats', {
        headers: { 'x-access-token': token }
      });
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  return (
    <div>
      <h2>Stats</h2>
      <p>Total Transactions: {stats.totalTransactions}</p>
      <p>Total Volume: {stats.totalVolume}</p>
    </div>
  );
}

export default Stats;
