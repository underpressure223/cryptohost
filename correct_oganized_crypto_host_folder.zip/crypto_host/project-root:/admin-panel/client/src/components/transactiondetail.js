import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import apiService from '../services/api.service';

function TransactionDetail() {
  const [transaction, setTransaction] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    fetchTransaction();
  }, [id]);

  const fetchTransaction = async () => {
    try {
      const response = await apiService.makeRequest('GET', `/transactions/${id}`);
      setTransaction(response);
    } catch (error) {
      console.error('Failed to fetch transaction:', error);
    }
  };

  if (!transaction) return <div>Loading...</div>;

  return (
    <div>
      <h2>Transaction Detail</h2>
      <p>From: {transaction.fromAddress}</p>
      <p>To: {transaction.toAddress}</p>
      <p>Amount: {transaction.amount}</p>
      <p>Status: {transaction.status}</p>
      <p>Created At: {new Date(transaction.createdAt).toLocaleString()}</p>
      <p>Transaction Hash: {transaction.txHash}</p>
    </div>
  );
}

export default TransactionDetail;
