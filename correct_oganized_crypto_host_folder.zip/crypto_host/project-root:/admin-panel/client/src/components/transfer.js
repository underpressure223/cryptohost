import React, { useState } from 'react';
import apiService from '../services/api.service';

function Transfer() {
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [authCode, setAuthCode] = useState('');
  const [result, setResult] = useState(null);

  const handleTransfer = async (e) => {
    e.preventDefault();
    try {
      const response = await apiService.makeRequest('POST', '/transfer', { toAddress, amount, authCode });
      setResult(response);
    } catch (error) {
      setResult({ error: error.message });
    }
  };

  return (
    <div>
      <h2>Transfer USDT</h2>
      <form onSubmit={handleTransfer}>
        <input
          type="text"
          value={toAddress}
          onChange={(e) => setToAddress(e.target.value)}
          placeholder="To Address"
          required
        />
        <input
          type="text"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount"
          required
        />
        <input
          type="text"
          value={authCode}
          onChange={(e) => setAuthCode(e.target.value)}
          placeholder="Auth Code"
          required
        />
        <button type="submit">Transfer</button>
      </form>
      {result && (
        <div>
          <h3>Result:</h3>
          <pre>{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default Transfer;
