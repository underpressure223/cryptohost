import apiService from './api.service';

const authService = {
  async login(username, password) {
    const response = await apiService.makeRequest('POST', '/auth/login', { username, password });
    if (response.token) {
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
    }
    return response.user;
  },

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user'));
  },
};

export default authService;
