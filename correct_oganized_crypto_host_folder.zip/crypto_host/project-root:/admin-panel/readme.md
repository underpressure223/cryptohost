# Admin Panel

The Admin Panel provides a user interface for managing and monitoring the USDT transfer system.

## Features

- User authentication
- Transaction monitoring
- User management
- Handshake initiation
- Balance checking
- USDT transfer initiation

## Setup

### Client

1. Navigate to the `client` directory.
2. Install dependencies:
npm install
3. Start the development server:
npm start

### Server

1. Navigate to the `server` directory.
2. Copy `.env.example` to `.env` and fill in the required values.
3. Install dependencies:
npm install
4. Start the server:
npm start

## Docker

To build and run using Docker:
docker-compose up --build

This will start both the client and server components of the Admin Panel.

## Environment Variables (Server)

- `PORT`: Server port (default: 5000)
- `MONGODB_URI`: MongoDB connection string
- `JWT_SECRET`: Secret for JWT tokens

## Environment Variables (Client)

- `REACT_APP_API_URL`: URL of the Admin Panel server API
