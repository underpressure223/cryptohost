{
  "name": "admin-panel-server",
  "version": "1.0.0",
  "description": "Server for USDT transfer admin panel",
  "main": "app.js",
  "scripts": {
    "start": "node app.js",
    "dev": "nodemon app.js"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "compression": "^1.7.4",
    "cors": "^2.8.5",
    "express": "^4.17.1",
    "helmet": "^4.6.0",
    "jsonwebtoken": "^8.5.1",
    "mongoose": "^5.12.3",
    "winston": "^3.3.3"
  },
  "devDependencies": {
    "nodemon": "^2.0.7"
  }
}
