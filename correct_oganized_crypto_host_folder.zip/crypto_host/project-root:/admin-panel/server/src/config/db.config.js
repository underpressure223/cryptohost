module.exports = {
  mongoURI: process.env.MONGODB_URI || 'mongodb://localhost:27017/admin_panel',
  jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret',
};
