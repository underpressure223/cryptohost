const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth.middleware');
const axios = require('axios');

router.post('/send', authMiddleware, async (req, res) => {
  const { method, url, body } = req.body;
  
  try {
    const response = await axios({
      method,
      url,
      data: body,
      headers: {
        'Content-Type': 'application/json',
        // Add any necessary headers for the Swift Global Server
      }
 });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ message: error.message, details: error.response?.data });
  }
});

module.exports = router;
