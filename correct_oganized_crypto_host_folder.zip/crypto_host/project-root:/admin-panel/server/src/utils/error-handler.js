const logger = require('./logger');

module.exports = (err, req, res, next) => {
  logger.error(err.stack);

  res.status(500).json({
    error: {
      message: 'An unexpected error occurred',
      status: 500,
    },
  });
};
