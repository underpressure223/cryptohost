const Joi = require('joi');

const validators = {
  loginSchema: Joi.object({
    username: Joi.string().alphanum().min(3).max(30).required(),
    password: Joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required()
  }),

  transactionSchema: Joi.object({
    fromAddress: Joi.string().required(),
    toAddress: Joi.string().required(),
    amount: Joi.number().positive().required()
  }),

  // Add more schemas as needed
};

module.exports = validators;
