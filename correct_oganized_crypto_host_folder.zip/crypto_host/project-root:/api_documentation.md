File:API_DOCUMENTATION.md
# API Documentation

## Check Balance

Initiate a balance check for a given API key.

**URL**: `/api/balance`
**Method**: `POST`
**Auth required**: Yes

### Request Body

```json
{
  "apiKey": "string"
}
Success Response
Code: 200 OK
Content:
{
  "balance": "string",
  "authCodeRequired": true,
  "message": "Please provide the authorization code to proceed with the transfer"
}
Transfer USDT
Perform a USDT transfer.
URL:/api/transfer
Method:POST
Auth required: Yes
Request Body
{
  "apiKey": "string",
  "toAddress": "string",
  "amount": "number",
  "authCode": "string"
}
Success Response
Code: 200 OK
Content:
{
  "success": true,
  "txHash": "string"
}
# These changes implement the following workflow:

1. The user initiates a balance check by sending a POST request with their API key.
2. The server contacts the global server to get the balance and informs the user that an authorization code is required for transfer.
3. For the transfer, the user must provide the API key, recipient address, amount, and the authorization code.
4. The server verifies the authorization code with the global server.
5. The server checks if the recipient wallet is pre-approved.
6. If all checks pass, the transfer is initiated using the Alchemy SDK.

This implementation ensures that:
- The balance check is performed via a POST request to the global server.
- An authorization code is required for transfers.
- The API key is used instead of a wallet address for identifying the source of funds.
- The recipient wallet is verified to be pre-approved before the transfer.

These additions provide a more comprehensive, production-ready codebase with improved security, performance, and documentation. The project now includes input sanitization, request throttling, a health check endpoint, graceful shutdown handling, and detailed API documentation.

# This setup accomplishes the following:

All interactions with the Swift global server now go through the crypto host server.
The Alchemy API key is stored and used only on the crypto host server, enhancing security.
The AWS API server communicates with the crypto host server, which in turn interacts with both the Swift global server and the Alchemy SDK.
Balance checks and transfers are performed using the Alchemy SDK on the crypto host server.

# To use this setup:

Deploy the crypto host server code to your EC2 instance.
Update the CRYPTO_HOST_URL in your AWS API server's .env file to point to your EC2 instance's domain or IP.
Ensure that the Alchemy API key is securely stored in the crypto host server's environment variables.
Update the Swift global server URL in both servers' configurations.

# This architecture provides an additional layer of security by keeping the Alchemy API key isolated on the crypto host server and using it as an intermediary for all sensitive operations.
