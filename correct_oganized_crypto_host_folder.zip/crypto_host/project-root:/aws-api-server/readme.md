# AWS API Server

This is the main API server for the USDT transfer system. It handles interactions with the Alchemy SDK and communicates with the Swift Global Server through the Crypto Host Server.

## Features

- Handshake with Swift Global Server
- Balance checking
- USDT transfers
- Transaction management

## Setup

1. Copy `.env.example` to `.env` and fill in the required values.
2. Install dependencies:
npm install
3. Run the server:
npm start
For development:
npm run dev
## Testing

Run the test suite:
npm test

## API Endpoints

- POST /api/handshake
- GET /api/balance
- POST /api/transfer

For detailed API documentation, please refer to the Swagger documentation.

## Docker

To build and run using Docker:
docker build -t aws-api-server .
docker run -p 3000:3000 aws-api-server

## Environment Variables

- `PORT`: Server port (default: 3000)
- `MONGODB_URI`: MongoDB connection string
- `REDIS_URL`: Redis connection string
- `JWT_SECRET`: Secret for JWT tokens
- `ALCHEMY_API_KEY`: Alchemy API key
- `SWIFT_GLOBAL_SERVER_URL`: URL of the Swi
