const express = require('express');
const basicAuth = require('express-basic-auth');
const morgan = require('morgan');
const TransactionModel = require('../models/transaction');

const app = express();

app.use(morgan('combined'));

app.use(basicAuth({
  users: { [process.env.ADMIN_USERNAME]: process.env.ADMIN_PASSWORD },
  challenge: true,
}));

app.get('/transactions', async (req, res) => {
  const transactions = await TransactionModel.find().sort('-createdAt').limit(100);
  res.json(transactions);
});

app.get('/stats', async (req, res) => {
  const totalTransactions = await TransactionModel.countDocuments();
  const totalVolume = await TransactionModel.aggregate([
    { $group: { _id: null, total: { $sum: "$amount" } } }
  ]);
  
  res.json({
    totalTransactions,
    totalVolume: totalVolume[0]?.total || 0
  });
});

const adminPort = process.env.ADMIN_PORT || 3001;
app.listen(adminPort, () => console.log(`Admin server running on port ${adminPort}`));
