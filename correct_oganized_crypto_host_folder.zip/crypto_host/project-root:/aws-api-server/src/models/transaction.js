const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  fromAddress: {
    type: String,
    required: true,
    index: true,
  },
  toAddress: {
    type: String,
    required: true,
    index: true,
  },
  amount: {
    type: String,
    required: true,
  },
  txHash: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed'],
    default: 'pending',
    index: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true,
  },
});

transactionSchema.index({ createdAt: 1, status: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
