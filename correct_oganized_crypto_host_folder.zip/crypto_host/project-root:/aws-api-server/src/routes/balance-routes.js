const express = require('express');
const alchemyService = require('../services/alchemy-service');
const authMiddleware = require('../middleware/auth-middleware');
const logger = require('../utils/logger');
const router = express.Router();

router.get('/', authMiddleware, async (req, res, next) => {
  try {
    const balance = await alchemyService.getBalance(req.user.address);
    logger.info(`Balance retrieved for address: ${req.user.address}`);
    res.json({ balance });
  } catch (error) {
    logger.error('Balance retrieval error:', error);
    next(error);
  }
});

module.exports = router;
