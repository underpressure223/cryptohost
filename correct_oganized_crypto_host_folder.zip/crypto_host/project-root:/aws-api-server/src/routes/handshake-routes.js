const express = require('express');
const globalServerService = require('../services/global-server-service');
const { validateHandshake } = require('../utils/validation-schemas');
const validate = require('../middleware/validate');
const logger = require('../utils/logger');
const router = express.Router();

router.post('/', validate(validateHandshake), async (req, res, next) => {
  try {
    const { serverId } = req.body;
    const handshakeResult = await globalServerService.performHandshake(serverId);
    
    logger.info(`Handshake successful for server ID: ${serverId}`);
    res.json({ success: true, message: 'Handshake successful', authCode: handshakeResult.authCode });
  } catch (error) {
    logger.error('Handshake error:', error);
    next(error);
  }
});

module.exports = router;
