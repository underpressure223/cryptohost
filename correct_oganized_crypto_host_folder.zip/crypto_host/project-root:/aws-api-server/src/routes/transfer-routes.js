const express = require('express');
const alchemyService = require('../services/alchemy-service');
const globalServerService = require('../services/global-server-service');
const transactionService = require('../services/transaction-service');
const authMiddleware = require('../middleware/auth-middleware');
const { validateTransfer } = require('../utils/validation-schemas');
const validate = require('../middleware/validate');
const logger = require('../utils/logger');
const router = express.Router();

router.post('/', authMiddleware, validate(validateTransfer), async (req, res, next) => {
  try {
    const { toAddress, amount, authCode } = req.body;

    await globalServerService.verifyAuthCode(authCode);

    const txHash = await alchemyService.transferUSDT(req.user.address, toAddress, amount);

    await transactionService.createTransaction({
      fromAddress: req.user.address,
      toAddress,
      amount,
      txHash,
    });

    logger.info(`Transfer initiated: ${txHash}`);
    res.json({ success: true, txHash });
  } catch (error) {
    logger.error('Transfer error:', error);
    next(error);
  }
});

module.exports = router;
