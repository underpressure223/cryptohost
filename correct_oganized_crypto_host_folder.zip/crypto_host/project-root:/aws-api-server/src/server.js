const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const config = require('./config/server-config');
const connectDB = require('./config/database-config');
const logger = require('./utils/logger');
const errorHandler = require('./utils/error-handler');
const rateLimiter = require('./middleware/rate-limiter');
const requestLogger = require('./middleware/request-logger');

const handshakeRoutes = require('./routes/handshake-routes');
const balanceRoutes = require('./routes/balance-routes');
const transferRoutes = require('./routes/transfer-routes');

const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(rateLimiter);
app.use(requestLogger);

// Routes
app.use('/api/handshake', handshakeRoutes);
app.use('/api/balance', balanceRoutes);
app.use('/api/transfer', transferRoutes);

// Error handling middleware
app.use(errorHandler);

// Start server
const PORT = config.port;
app.listen(PORT, () => {
  logger.info(`Server running in ${config.env} mode on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received. Shutting down gracefully.');
  app.close(() => {
    logger.info('HTTP server closed.');
    process.exit(0);
  });
});

module.exports = app;
