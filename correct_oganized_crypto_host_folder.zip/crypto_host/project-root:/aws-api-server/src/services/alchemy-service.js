const alchemy = require('../config/alchemy-config');
const logger = require('../utils/logger');

class AlchemyService {
  async getBalance(address) {
    try {
      const balance = await alchemy.core.getBalance(address);
      return alchemy.utils.formatEther(balance);
    } catch (error) {
      logger.error('Failed to get balance:', error);
      throw new Error(`Failed to get balance: ${error.message}`);
    }
  }

  async transferUSDT(fromAddress, toAddress, amount) {
    try {
      const transaction = await alchemy.core.sendTransaction({
        to: toAddress,
        from: fromAddress,
        value: alchemy.utils.parseEther(amount),
      });
      return transaction.hash;
    } catch (error) {
      logger.error('Failed to transfer USDT:', error);
      throw new Error(`Failed to transfer USDT: ${error.message}`);
    }
  }
}

module.exports = new AlchemyService();
