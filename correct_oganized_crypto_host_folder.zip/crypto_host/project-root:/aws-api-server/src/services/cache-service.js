const redisClient = require('../config/redis-config');
const logger = require('../utils/logger');

class CacheService {
  async get(key) {
    try {
      const value = await redisClient.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error('Cache get error:', error);
      return null;
    }
  }

  async set(key, value, expireTime = 3600) {
    try {
      await redisClient.set(key, JSON.stringify(value), 'EX', expireTime);
    } catch (error) {
      logger.error('Cache set error:', error);
    }
  }

  async del(key) {
    try {
      await redisClient.del(key);
    } catch (error) {
      logger.error('Cache delete error:', error);
    }
  }

  async getOrSet(key, callback, expireTime = 3600) {
    try {
      const cachedValue = await this.get(key);
      if (cachedValue) {
        return cachedValue;
      }
      const freshValue = await callback();
      await this.set(key, freshValue, expireTime);
      return freshValue;
    } catch (error) {
      logger.error('Cache getOrSet error:', error);
      return null;
    }
  }
}

module.exports = new CacheService();
