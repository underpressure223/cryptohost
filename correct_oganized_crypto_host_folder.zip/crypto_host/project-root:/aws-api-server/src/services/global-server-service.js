const axios = require('axios');
const logger = require('../utils/logger');
const config = require('../config/server-config');

class GlobalServerService {
  constructor() {
    this.axiosInstance = axios.create({
      baseURL: config.swiftGlobalServerUrl,
      timeout: 5000,
    });
  }

  async performHandshake(serverId) {
    try {
      const response = await this.axiosInstance.post('/handshake', { serverId });
      logger.info('Handshake successful');
      return response.data;
    } catch (error) {
      logger.error('Handshake failed:', error);
      throw new Error(`Handshake failed: ${error.message}`);
    }
  }

  async verifyAuthCode(authCode) {
    try {
      const response = await this.axiosInstance.post('/verify', { authCode });
      logger.info('Auth code verified');
      return response.data;
    } catch (error) {
      logger.error('Auth code verification failed:', error);
      throw new Error(`Auth code verification failed: ${error.message}`);
    }
  }
}

module.exports = new GlobalServerService();
