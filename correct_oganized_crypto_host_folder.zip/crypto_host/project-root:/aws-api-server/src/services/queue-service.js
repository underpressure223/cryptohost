const Queue = require('bull');
const logger = require('../utils/logger');
const transferService = require('./transfer-service');

const transferQueue = new Queue('transfer-queue', process.env.REDIS_URL);

transferQueue.process(async (job) => {
  try {
    const { fromAddress, toAddress, amount, authCode } = job.data;
    await transferService.performTransfer(fromAddress, toAddress, amount, authCode);
    logger.info(`Transfer completed: ${job.id}`);
  } catch (error) {
    logger.error(`Transfer failed: ${job.id}`, error);
    throw error;
  }
});

const queueTransfer = async (fromAddress, toAddress, amount, authCode) => {
  const job = await transferQueue.add({
    fromAddress,
    toAddress,
    amount,
    authCode
  });
  logger.info(`Transfer queued: ${job.id}`);
  return job.id;
};

module.exports = { queueTransfer };
