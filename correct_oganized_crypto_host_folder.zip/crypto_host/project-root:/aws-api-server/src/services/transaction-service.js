const Transaction = require('../models/transaction');
const logger = require('../utils/logger');

class TransactionService {
  async createTransaction(transactionData) {
    try {
      const transaction = new Transaction(transactionData);
      await transaction.save();
      logger.info(`Transaction created: ${transaction._id}`);
      return transaction;
    } catch (error) {
      logger.error('Failed to create transaction:', error);
      throw new Error(`Failed to create transaction: ${error.message}`);
    }
  }

  async updateTransactionStatus(txHash, status) {
    try {
      const updatedTransaction = await Transaction.findOneAndUpdate(
        { txHash },
        { status },
        { new: true }
      );
      logger.info(`Transaction ${txHash} status updated to ${status}`);
      return updatedTransaction;
    } catch (error) {
      logger.error('Failed to update transaction status:', error);
      throw new Error(`Failed to update transaction status: ${error.message}`);
    }
  }

  async getTransactions(filter = {}, page = 1, limit = 20) {
    try {
      const transactions = await Transaction.find(filter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit);
      const total = await Transaction.countDocuments(filter);
      return { transactions, total, page, totalPages: Math.ceil(total / limit) };
    } catch (error) {
      logger.error('Failed to get transactions:', error);
      throw new Error(`Failed to get transactions: ${error.message}`);
    }
  }
}

module.exports = new TransactionService();
