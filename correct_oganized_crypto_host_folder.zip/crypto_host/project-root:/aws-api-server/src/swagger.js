{
    "openapi": "3.0.0",
    "info": {
      "title": "USDT Transfer API",
      "version": "1.0.0",
      "description": "API for handling USDT transfers and interactions with the Swift Global Server"
    },
    "servers": [
      {
        "url": "https://api.atlan10s.com/v1"
      }
    ],
    "paths": {
      "/handshake": {
        "post": {
          "summary": "Perform handshake with Swift Global Server",
          "requestBody": {
            "required": true,
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "serverId": {
                      "type": "string"
                    }
                  },
                  "required": ["serverId"]
                }
              }
            }
          },
          "responses": {
            "200": {
              "description": "Successful handshake",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "success": {
                        "type": "boolean"
                      },
                      "authCode": {
                        "type": "string"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/balance": {
        "get": {
          "summary": "Get USDT balance",
          "parameters": [
            {
              "in": "header",
              "name": "Authorization",
              "required": true,
              "schema": {
                "type": "string"
              }
            }
          ],
          "responses": {
            "200": {
              "description": "Successful balance retrieval",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "balance": {
                        "type": "string"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
      "/transfer": {
        "post": {
          "summary": "Transfer USDT",
          "requestBody": {
            "required": true,
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "toAddress": {
                      "type": "string"
                    },
                    "amount": {
                      "type": "string"
                    },
                    "authCode": {
                      "type": "string"
                    }
                  },
                  "required": ["toAddress", "amount", "authCode"]
                }
              }
            }
          },
          "responses": {
            "200": {
              "description": "Successful transfer",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "success": {
                        "type": "boolean"
                      },
                      "txHash": {
                        "type": "string"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  