const CircuitBreaker = require('opossum');
const logger = require('./logger');

const defaultOptions = {
  timeout: 3000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000
};

const createBreaker = (func, options = {}) => {
  const breaker = new CircuitBreaker(func, { ...defaultOptions, ...options });

  breaker.on('open', () => logger.warn('Circuit Breaker opened'));
  breaker.on('halfOpen', () => logger.info('Circuit Breaker half-open'));
  breaker.on('close', () => logger.info('Circuit Breaker closed'));

  return breaker;
};

module.exports = createBreaker;
