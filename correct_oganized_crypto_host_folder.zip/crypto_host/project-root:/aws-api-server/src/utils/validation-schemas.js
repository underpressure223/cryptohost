const Joi = require('joi');

const schemas = {
  validateHandshake: Joi.object({
    serverId: Joi.string().required(),
  }),

  validateTransfer: Joi.object({
    toAddress: Joi.string().pattern(/^0x[a-fA-F0-9]{40}$/).required(),
    amount: Joi.string().pattern(/^\d+(\.\d+)?$/).required(),
    authCode: Joi.string().required(),
  }),
};

module.exports = schemas;
