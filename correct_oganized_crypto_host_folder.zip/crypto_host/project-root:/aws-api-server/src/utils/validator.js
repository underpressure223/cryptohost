const Joi = require('joi');
const logger = require('./logger');

const validateHandshake = (req, res, next) => {
  const schema = Joi.object({
    serverId: Joi.string().required(),
  });

  const { error } = schema.validate(req.body);
  if (error) {
    logger.warn('Invalid handshake request:', error);
    return res.status(400).json({ error: error.details[0].message });
  }

  next();
};

const validateTransfer = (req, res, next) => {
  const schema = Joi.object({
    toAddress: Joi.string().pattern(/^0x[a-fA-F0-9]{40}$/).required(),
    amount: Joi.string().pattern(/^\d+(\.\d+)?$/).required(),
    authCode: Joi.string().required(),
  });

  const { error } = schema.validate(req.body);
  if (error) {
    logger.warn('Invalid transfer request:', error);
    return res.status(400).json({ error: error.details[0].message });
  }

  next();
};

module.exports = {
  validateHandshake,
  validateTransfer,
};
