const request = require('supertest');
const { expect } = require('chai');
const sinon = require('sinon');
const app = require('../../../src/server');
const globalServerService = require('../../../src/services/global-server-service');

describe('Handshake API', () => {
  afterEach(() => {
    sinon.restore();
  });

  describe('POST /api/handshake', () => {
    it('should perform handshake successfully', async () => {
      const mockHandshakeResult = { authCode: 'test-auth-code' };
      sinon.stub(globalServerService, 'performHandshake').resolves(mockHandshakeResult);

      const res = await request(app)
        .post('/api/handshake')
        .send({ serverId: 'test-server-id' });

      expect(res.status).to.equal(200);
      expect(res.body).to.deep.equal({
        success: true,
        message: 'Handshake successful',
        authCode: 'test-auth-code'
      });
    });

    it('should return 400 for invalid input', async () => {
      const res = await request(app)
        .post('/api/handshake')
        .send({});

      expect(res.status).to.equal(400);
      expect(res.body).to.have.property('error');
    });

    it('should handle errors from global server service', async () => {
      sinon.stub(globalServerService, 'performHandshake').rejects(new Error('Global server error'));

      const res = await request(app)
        .post('/api/handshake')
        .send({ serverId: 'test-server-id' });

      expect(res.status).to.equal(500);
      expect(res.body).to.have.property('error');
    });
  });
});
