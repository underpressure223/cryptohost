const request = require('supertest');
const { expect } = require('chai');
const sinon = require('sinon');
const app = require('../../../src/server');
const alchemyService = require('../../../src/services/alchemy-service');
const globalServerService = require('../../../src/services/global-server-service');
const transactionService = require('../../../src/services/transaction-service');

describe('Transfer API', () => {
  afterEach(() => {
    sinon.restore();
  });

  describe('POST /api/transfer', () => {
    it('should perform transfer successfully', async () => {
      const mockUser = { address: '0x1234567890123456789012345678901234567890' };
      const mockAuthCode = 'valid-auth-code';
      const mockTxHash = '0xabcdef1234567890';

      sinon.stub(globalServerService, 'verifyAuthCode').resolves();
      sinon.stub(alchemyService, 'transferUSDT').resolves(mockTxHash);
      sinon.stub(transactionService, 'createTransaction').resolves();

      const res = await request(app)
        .post('/api/transfer')
        .set('Authorization', 'Bearer valid-token')
        .send({
          toAddress: '0x0987654321098765432109876543210987654321',
          amount: '100',
          authCode: mockAuthCode
        });

      expect(res.status).to.equal(200);
      expect(res.body).to.deep.equal({
        success: true,
        txHash: mockTxHash
      });
    });

    it('should return 400 for invalid input', async () => {
      const res = await request(app)
        .post('/api/transfer')
        .set('Authorization', 'Bearer valid-token')
        .send({
          toAddress: 'invalid-address',
          amount: 'not-a-number',
          authCode: 'valid-auth-code'
        });

      expect(res.status).to.equal(400);
      expect(res.body).to.have.property('error');
    });

    it('should return 401 for invalid token', async () => {
      const res = await request(app)
        .post('/api/transfer')
        .set('Authorization', 'Bearer invalid-token')
        .send({
          toAddress: '0x0987654321098765432109876543210987654321',
          amount: '100',
          authCode: 'valid-auth-code'
        });

      expect(res.status).to.equal(401);
      expect(res.body).to.have.property('error');
    });

    // Add more test cases for different scenarios
  });
});
