const { expect } = require('chai');
const sinon = require('sinon');
const AlchemyService = require('../../../src/services/alchemy-service');
const alchemy = require('../../../src/config/alchemy-config');

describe('Alchemy Service', () => {
  let alchemyService;

  beforeEach(() => {
    alchemyService = new AlchemyService();
  });

  afterEach(() => {
    sinon.restore();
  });

  describe('getBalance', () => {
    it('should return formatted balance', async () => {
      const mockBalance = '1000000000000000000'; // 1 ETH in wei
      sinon.stub(alchemy.core, 'getBalance').resolves(mockBalance);
      sinon.stub(alchemy.utils, 'formatEther').returns('1.0');

      const address = '0x1234567890123456789012345678901234567890';
      const balance = await alchemyService.getBalance(address);

      expect(balance).to.equal('1.0');
      expect(alchemy.core.getBalance.calledOnceWith(address)).to.be.true;
      expect(alchemy.utils.formatEther.calledOnceWith(mockBalance)).to.be.true;
    });

    it('should throw an error if Alchemy API fails', async () => {
      sinon.stub(alchemy.core, 'getBalance').rejects(new Error('API Error'));

      const address = '0x1234567890123456789012345678901234567890';
      
      await expect(alchemyService.getBalance(address)).to.be.rejectedWith('Failed to get balance: API Error');
    });
  });

  // Add more tests for transferUSDT method
});
