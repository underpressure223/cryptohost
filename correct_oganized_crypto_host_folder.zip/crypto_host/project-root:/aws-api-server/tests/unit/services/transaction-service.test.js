const { expect } = require('chai');
const sinon = require('sinon');
const TransactionService = require('../../../src/services/transaction-service');
const Transaction = require('../../../src/models/transaction');

describe('Transaction Service', () => {
  let transactionService;

  beforeEach(() => {
    transactionService = new TransactionService();
  });

  afterEach(() => {
    sinon.restore();
  });

  describe('createTransaction', () => {
    it('should create a new transaction', async () => {
      const transactionData = {
        fromAddress: '0x123',
        toAddress: '0x456',
        amount: '100',
        txHash: '0xabcdef'
      };

      const saveStub = sinon.stub(Transaction.prototype, 'save').resolves(transactionData);

      const result = await transactionService.createTransaction(transactionData);

      expect(result).to.deep.equal(transactionData);
      expect(saveStub.calledOnce).to.be.true;
    });

    it('should throw an error if creation fails', async () => {
      const transactionData = {
        fromAddress: '0x123',
        toAddress: '0x456',
        amount: '100',
        txHash: '0xabcdef'
      };

      sinon.stub(Transaction.prototype, 'save').rejects(new Error('Database error'));

      await expect(transactionService.createTransaction(transactionData)).to.be.rejectedWith('Failed to create transaction: Database error');
    });
  });

  // Add more tests for other methods in TransactionService
});
