# Crypto Host Server

This server acts as an intermediary between the AWS API Server and the Swift Global Server, providing an additional layer of security for sensitive operations.

## Features

- Secure communication with Swift Global Server
- Handshake relay
- Balance check relay
- Transfer relay

## Setup

1. Copy `.env.example` to `.env` and fill in the required values.
2. Install dependencies:
npm install
3. Run the server:
npm start

For development:
npm run dev

## API Endpoints

- POST /api/handshake
- GET /api/balance
- POST /api/transfer

These endpoints mirror those of the AWS API Server but add an additional layer of security.

## Docker

To build and run using Docker:
docker build -t crypto-host-server .
docker run -p 3001:3001 crypto-host-server

## Environment Variables

- `PORT`: Server port (default: 3001)
- `JWT_SECRET`: Secret for JWT tokens
- `ALCHEMY_API_KEY`: Alchemy API key
- `SWIFT_GLOBAL_SERVER_URL`: URL of the Swift Global Server
