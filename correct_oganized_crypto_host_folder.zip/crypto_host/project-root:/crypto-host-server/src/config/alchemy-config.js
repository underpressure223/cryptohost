const { Alchemy, Network } = require("alchemy-sdk");
const logger = require('../utils/logger');

if (!process.env.ALCHEMY_API_KEY) {
  logger.error('ALCHEMY_API_KEY is not set in the environment variables');
  process.exit(1);
}

const settings = {
  apiKey: process.env.ALCHEMY_API_KEY,
  network: Network.ETH_MAINNET,
  maxRetries: 5,
  requestTimeout: 30000,
};

const alchemy = new Alchemy(settings);

module.exports = alchemy;
