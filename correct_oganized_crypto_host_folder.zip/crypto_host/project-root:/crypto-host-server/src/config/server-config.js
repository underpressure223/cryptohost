require('dotenv').config();

module.exports = {
  port: process.env.PORT || 3001,
  env: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET,
  jwtExpirationInterval: process.env.JWT_EXPIRATION_MINUTES,
  alchemyApiKey: process.env.ALCHEMY_API_KEY,
  swiftGlobalServerUrl: process.env.SWIFT_GLOBAL_SERVER_URL,
};
