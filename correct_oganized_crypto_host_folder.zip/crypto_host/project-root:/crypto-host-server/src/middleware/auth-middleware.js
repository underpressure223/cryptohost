const jwt = require('jsonwebtoken');
const config = require('../config/server-config');
const logger = require('../utils/logger');

module.exports = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];

  if (!token) {
    logger.warn('No token provided');
    return res.status(401).json({ error: 'No token, authorization denied' });
  }

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    req.user = decoded.user;
    next();
  } catch (err) {
    logger.error('Invalid token:', err);
    res.status(401).json({ error: 'Token is not valid' });
  }
};
