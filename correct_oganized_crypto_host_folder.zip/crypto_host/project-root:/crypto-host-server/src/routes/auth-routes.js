const express = require('express');
const swiftGlobalService = require('../services/swift-global-service');
const logger = require('../utils/logger');
const router = express.Router();

router.post('/verify', async (req, res, next) => {
  try {
    const { authCode, apiKey } = req.body;
    const result = await swiftGlobalService.verifyAuthCode(authCode, apiKey);
    logger.info(`Auth code verified for API key: ${apiKey}`);
    res.json(result);
  } catch (error) {
    logger.error('Auth verification error:', error);
    next(error);
  }
});

module.exports = router;
