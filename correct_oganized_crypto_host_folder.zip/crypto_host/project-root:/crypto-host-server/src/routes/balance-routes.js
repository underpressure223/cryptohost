const express = require('express');
const swiftGlobalService = require('../services/swift-global-service');
const logger = require('../utils/logger');
const router = express.Router();

router.post('/', async (req, res, next) => {
  try {
    const { serverId } = req.body;
    const result = await swiftGlobalService.performHandshake(serverId);
    logger.info(`Handshake performed for server ID: ${serverId}`);
    res.json(result);
  } catch (error) {
    logger.error('Handshake error:', error);
    next(error);
  }
});

module.exports = router;
