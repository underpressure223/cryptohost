const express = require('express');
const swiftGlobalService = require('../services/swift-global-service');
const authMiddleware = require('../middleware/auth-middleware');
const logger = require('../utils/logger');
const router = express.Router();

router.post('/', authMiddleware, async (req, res, next) => {
  try {
    const { toAddress, amount, authCode } = req.body;
    const result = await swiftGlobalService.transfer(req.user.address, toAddress, amount, authCode);
    logger.info(`Transfer initiated from ${req.user.address} to ${toAddress}`);
    res.json(result);
  } catch (error) {
    logger.error('Transfer error:', error);
    next(error);
  }
});

module.exports = router;
