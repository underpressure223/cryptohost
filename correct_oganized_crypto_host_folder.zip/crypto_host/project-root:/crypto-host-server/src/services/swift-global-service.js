const axios = require('axios');
const logger = require('../utils/logger');
const config = require('../config/server-config');

class SwiftGlobalService {
  constructor() {
    this.axiosInstance = axios.create({
      baseURL: config.swiftGlobalServerUrl,
      timeout: 10000,
    });
  }

  async performHandshake(serverId) {
    try {
      const response = await this.axiosInstance.post('/handshake', { serverId });
      logger.info('Handshake successful');
      return response.data;
    } catch (error) {
      logger.error('Handshake failed:', error);
      throw new Error(`Handshake failed: ${error.message}`);
    }
  }

  async checkBalance(address) {
    try {
      const response = await this.axiosInstance.get('/balance', { params: { address } });
      logger.info('Balance check successful');
      return response.data.balance;
    } catch (error) {
      logger.error('Balance check failed:', error);
      throw new Error(`Balance check failed: ${error.message}`);
    }
  }

  async transfer(fromAddress, toAddress, amount, authCode) {
    try {
      const response = await this.axiosInstance.post('/transfer', {
        fromAddress,
        toAddress,
        amount,
        authCode
      });
      logger.info('Transfer request successful');
      return response.data;
    } catch (error) {
      logger.error('Transfer failed:', error);
      throw new Error(`Transfer failed: ${error.message}`);
    }
  }
}

module.exports = new SwiftGlobalService();
