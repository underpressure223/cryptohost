#!/bin/bash

# Wait for Vault to start
sleep 10

# Initialize Vault
vault operator init -key-shares=1 -key-threshold=1 > vault-keys.txt

# Unseal Vault
UNSEAL_KEY=$(grep 'Unseal Key 1:' vault-keys.txt | awk '{print $NF}')
vault operator unseal $UNSEAL_KEY

# Authenticate
ROOT_TOKEN=$(grep 'Initial Root Token:' vault-keys.txt | awk '{print $NF}')
vault login $ROOT_TOKEN

# Enable the KV secrets engine
vault secrets enable -path=secret kv

# Add our secrets
vault kv put secret/usdt-transfer \
    alchemy_api_key=${ALCHEMY_API_KEY} \
    swift_global_server_url=${SWIFT_GLOBAL_SERVER_URL} \
    jwt_secret=${JWT_SECRET}

echo "Vault initialized and secrets added."
