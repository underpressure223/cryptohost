# USDT Transfer System

This project implements a secure system for transferring USDT using the Alchemy SDK and interacting with a Swift Global Server. It includes an AWS API server, a Crypto Host server, and an Admin Panel for managing operations.

## Components

1. [AWS API Server](./aws-api-server/README.md)
2. [Crypto Host Server](./crypto-host-server/README.md)
3. [Admin Panel](./admin-panel/README.md)

## Architecture

- The AWS API Server handles the main logic for USDT transfers and interactions with the Alchemy SDK.
- The Crypto Host Server acts as a secure intermediary between the AWS API Server and the Swift Global Server.
- The Admin Panel provides a user interface for monitoring and managing the system.

## Setup

1. Clone the repository:
git clone https://github.com/your-username/usdt-transfer-system.git cd usdt-transfer-system

2. Run the setup script:
node scripts/setup.js

3. Update the `.env` files in each component directory with your configuration.

4. Initialize the database:
node scripts/dbInit.js

5. Start the services using Docker Compose:
docker-compose up --build

## Development

For development, use the development Docker Compose file:
docker-compose -f docker-compose.dev.yml up --build

## Security

- All sensitive information is stored in HashiCorp Vault.
- Communication between components is encrypted.
- The Crypto Host Server provides an additional layer of security for interactions with the Swift Global Server.

## Monitoring

The ELK (Elasticsearch, Logstash, Kibana) stack is set up for log aggregation and monitoring. Access Kibana at `http://localhost:5601`.

## Testing

Each component has its own test suite. Refer to the individual README files for instructions on running tests.

## Deployment

For production deployment:

1. Ensure all environment variables are properly set.
2. Use a reverse proxy like Nginx to handle SSL termination and load balancing.
3. Set up proper firewalls and network security groups.
4. Implement regular database backups.
5. Set up monitoring and alerting for all components.

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct and the process for submitting pull requests.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.
These README files provide comprehensive documentation for each component of the system as well as an overview of the entire project. They include setup instructions, features, and important information for development and deployment.
