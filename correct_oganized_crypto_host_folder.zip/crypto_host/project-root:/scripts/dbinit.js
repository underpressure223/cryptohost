const mongoose = require('mongoose');
const config = require('../aws-api-server/src/config/server-config');

async function initDatabase() {
  try {
    await mongoose.connect(config.mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
    });
    console.log('Connected to MongoDB');

    // Perform any necessary database setup or migrations here

    console.log('Database initialization complete');
  } catch (error) {
    console.error('Database initialization failed:', error);
  } finally {
    mongoose.disconnect();
  }
}

initDatabase();
