const fs = require('fs');
const { execSync } = require('child_process');

function copyEnvFile(service) {
  fs.copyFileSync(`./${service}/.env.example`, `./${service}/.env`);
  console.log(`Created .env file for ${service}`);
}

function installDependencies(service) {
  console.log(`Installing dependencies for ${service}...`);
  execSync(`cd ${service} && npm install`, { stdio: 'inherit' });
}

function setup() {
  const services = ['aws-api-server', 'crypto-host-server', 'admin-panel/server', 'admin-panel/client'];

  services.forEach((service) => {
    copyEnvFile(service);
    installDependencies(service);
  });

  console.log('Setup complete. Please update the .env files with your configuration.');
}

setup();
